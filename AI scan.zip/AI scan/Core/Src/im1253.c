/*
 * im243b_device.c
 *
 *  Created on: Jul 6, 2023
 *      Author: katsu
 */

/* USER CODE BEGIN 0 */
#include <stdio.h>
#include "im1253.h"
#include "main.h"

/*
 * UART_DEVICE used for communication between device and stm32
 * UART_PC used for send debug info and data to PC
 * */
#define UART_DEVICE huart3
#define UART_PC huart4

extern UART_HandleTypeDef UART_DEVICE;
extern UART_HandleTypeDef UART_PC;

unsigned long voltage_data=0,current_data=0,power_data=0,energy_data=0,pf_data,co2_data=0;

uint8_t device_response_buffer[37];

#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int _io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__*/

/******************************************************************
 *@brief  Retargets the C library printf  function to the USART.
 *@param  None
 *@retval None
 ******************************************************************/

PUTCHAR_PROTOTYPE
{
  HAL_UART_Transmit(&UART_PC, (uint8_t*) &ch, 1, 0xFFFF);
  return ch;
}


int _write(int file, char *ptr, int len)
{
  int DataIdx;
  for (DataIdx = 0; DataIdx < len; DataIdx++)
    _io_putchar(*ptr++);
  return len;
}
/*
 *
 * */
void send_to_pc(unsigned long data)
{
  printf("%.4f ", data,'/r/n');
  fflush(stdout);
  return;
}


void device_read()
{
  const char *cmd_read = "\x01\x03\x00\x48\x00\x08\xc4\x1a";   //���豸���Ͷ�ȡͨ��
  HAL_UART_Transmit(&UART_DEVICE, (uint8_t *)cmd_read, 8, 0xffff);
  if(__HAL_UART_GET_FLAG(&huart3, UART_CLEAR_OREF) != RESET)
     {
         //ȡ�����ڻ����ж�����ֽ���
         uint8_t data = (uint8_t)(huart3.Instance->RDR);
         //���ORE����
         __HAL_UART_CLEAR_FLAG(&huart3, UART_CLEAR_OREF);
     }

  	  if (HAL_OK != HAL_UART_Receive(&UART_DEVICE, device_response_buffer, 37, 0xffff))
  	  {
  		  printf("Device Read Failed\r\n");
  	  }
  	  else
  	  {
  		  analysis_data();
  	  }
}



void device_clear()
{
  const char *cmd_clear = "\x01\x10\x00\x4b\x00\x02\x04\x00\x00\x00\x00\xb6\x2c";
  HAL_UART_Transmit(&UART_DEVICE, (uint8_t *)cmd_clear, 13, 0xffff);
  HAL_Delay(300);
  if (HAL_OK != HAL_UART_Receive(&UART_DEVICE, device_response_buffer, 8, 0xffff))
  {
    printf("Device Read Failed\r\n");
  }

}



void analysis_data(void)
{
    //���ݽ���
    unsigned long Voltage_data=(((unsigned long)(device_response_buffer[3]))<<24)|(((unsigned
                 long)(device_response_buffer[4]))<<16)|(((unsigned long)(device_response_buffer[5]))<<8)|device_response_buffer[6];
    unsigned long Current_data=(((unsigned long)(device_response_buffer[7]))<<24)|(((unsigned
                 long)(device_response_buffer[8]))<<16)|(((unsigned long)(device_response_buffer[9]))<<8)|device_response_buffer[10];
    unsigned long Power_data=(((unsigned long)(device_response_buffer[11]))<<24)|(((unsigned
               long)(device_response_buffer[12]))<<16)|(((unsigned long)(device_response_buffer[13]))<<8)|device_response_buffer[14];
    unsigned long Energy_data=(((unsigned long)(device_response_buffer[15]))<<24)|(((unsigned
                long)(device_response_buffer[16]))<<16)|(((unsigned long)(device_response_buffer[17]))<<8)|device_response_buffer[18];
    unsigned long Pf_data=(((unsigned long)(device_response_buffer[19]))<<24)|(((unsigned
            long)(device_response_buffer[20]))<<16)|(((unsigned long)(device_response_buffer[21]))<<8)|device_response_buffer[22];
    unsigned long CO2_data=(((unsigned long)(device_response_buffer[23]))<<24)|(((unsigned
             long)(device_response_buffer[24]))<<16)|(((unsigned long)(device_response_buffer[25]))<<8)|device_response_buffer[26];
    voltage_data = Voltage_data * 0.001;
    current_data = Current_data *0.001;
    power_data = Power_data *0.001;
    energy_data = Energy_data *0.001;
    pf_data = Pf_data *0.001;
    co2_data = CO2_data *0.001;
}
