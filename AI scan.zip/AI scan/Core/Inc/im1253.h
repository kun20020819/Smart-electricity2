
#ifndef INC_IM1253_H_
#define INC_IM1253_H_
/*
 * im1253b_device.h
 *
 *  Created on: Jul 7, 2023
 *      Author: katsu
 */



extern unsigned long voltage_data, current_data, power_data, energy_data,
    pf_data, co2_data;

void send_to_pc(unsigned long data);
void device_read();
void device_clear();
void analysis_data();



#endif /* INC_IM1253_H_ */
